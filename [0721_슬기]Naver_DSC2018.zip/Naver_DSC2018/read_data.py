# -*- coding: utf-8 -*-
"""
Created on Sat Jul 21 00:26:44 2018

@author: gjrm2
"""

import pandas as pd
import numpy as np


# utf-8 encoding error, so I take 'cp1252'
data = pd.read_csv('laptops.csv', encoding= "cp1252")


# 일단 그러면 data라는 변수에 들어가있음.
# spyder에서 우측에 variable explorer에서 더블클릭하면 직접 열어볼 수 있음

# 이제 파이썬 이용해서 통계내는 방법들을 검색하고 따라해보자!