# -*- coding: utf-8 -*-
"""
Created on Fri Jul 27 12:56:53 2018

@author: qgqg2
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jul 26 19:58:15 2018

@author: qgqg2
"""

import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import collections
from sklearn import datasets, linear_model
# utf-8 encoding error, so I take 'cp1252'
df = pd.read_csv('Processed_Data.csv', encoding= "cp1252")

df['Gpu_Type'] = df.Gpu.apply(lambda e: e.split()[0])
df['Gpu_temp'] = df.Gpu.apply(lambda e: e.split()[-1])

Gpu_intel = df.loc[df['Gpu_Type'] == 'Intel']
#Gpu_intel['Gpu_temp'] = Gpu_intel.apply(lambda e :e.split()[-1])
Gpu_intel['Gpu_modified'] = Gpu_intel['Gpu']



df['Gpu_modified'] = df['Gpu']
df.loc[df["Gpu_Type"] == 'AMD', "Gpu_modified"] =7
df.loc[df["Gpu_Type"] == 'ARM', "Gpu_modified"] =6
#df.loc[df["Gpu_Type"] == 'Intel', "Gpu_modified"] =10 + df['Gpu_temp']/1000
df.loc[df["Gpu_Type"] == 'Nvidia', "Gpu_modified"] =15
df.loc[Gpu_intel['Gpu_temp' != 'Graphics'],"Gpu_modified"] = 10 + Gpu_intel['Gpu_temp']/1000
df['Gpu_modified'] = df['Gpu_modified'].apply(pd.to_numeric)

Corr = df.corr()

Price_by_Gpu = df.groupby('Gpu_Type').mean()
print(Price_by_Gpu['Price_euros'])